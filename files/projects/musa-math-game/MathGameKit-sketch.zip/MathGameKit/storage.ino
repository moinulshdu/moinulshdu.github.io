/*
  =====================================================================
   storage  -  saving progress in the Nano's EEPROM
  =====================================================================
   EEPROM is 1024 bytes inside the Nano that keep their contents with
   the power off. We use:
     byte 0       : 78, a marker meaning "saved here before"
     bytes 1..8   : the level of game 1..8 (in the order of games.h)
     bytes 9..10  : number of sessions played
*/

const byte SAVE_MARKER = 78;

void loadProgress() {
  for (int g = 0; g < MAX_GAMES; g++) {
    levels[g] = LEVEL_START;
  }
  if (RESET_PROGRESS || EEPROM.read(0) != SAVE_MARKER) {
    saveProgress();                        // first time ever (or a reset)
    return;
  }
  for (int g = 0; g < MAX_GAMES; g++) {
    levels[g] = constrain(EEPROM.read(1 + g), LEVEL_MIN, LEVEL_MAX);
  }
  EEPROM.get(9, sessionCount);
}

void saveProgress() {
  EEPROM.update(0, SAVE_MARKER);           // update() only writes bytes that changed
  for (int g = 0; g < MAX_GAMES; g++) {
    EEPROM.update(1 + g, levels[g]);
  }
  EEPROM.put(9, sessionCount);
}
