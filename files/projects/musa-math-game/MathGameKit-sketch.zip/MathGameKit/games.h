/*
  =====================================================================
   games.h  -  THE LIST OF GAMES
  =====================================================================
   To add a new MATH game (for example subtraction):
     1. Copy the tab game_addition.ino, rename it game_subtraction.ino,
        and change the function inside (see the notes in that tab).
     2. Add one line "void makeSubtraction(int level, Problem &p);" below.
     3. Add one line to the END of the GAMES list below, like
            {'C', "MUSA  5-3", makeSubtraction, nullptr},
   That's it. The menu, sounds, tries, levels and saving all work
   automatically, and each game keeps its own level.

   Important: keep the order of the list the same once games have been
   played, because each game's saved level is stored by its position.
*/
#ifndef GAMES_H
#define GAMES_H

#include "config.h"

// 1) One line per game function (the functions live in the game_*.ino tabs)
void makeAddition(int level, Problem &p);
void playLetters();

// 2) The menu: key, name on screen, math function, activity function.
//    A math game fills in the 3rd item and puts nullptr in the 4th.
//    An activity puts nullptr in the 3rd and fills in the 4th.
const Game GAMES[] = {
  {'A', "MUSA  1+2", makeAddition, nullptr},       // MUSA: adaptive addition
  {'B', "ISA   ABC", nullptr,      playLetters},    // ISA: letters A-Z, no score
  // {'C', "MUSA  5-3", makeSubtraction, nullptr},
};

const int GAME_COUNT = sizeof(GAMES) / sizeof(GAMES[0]);

#endif
