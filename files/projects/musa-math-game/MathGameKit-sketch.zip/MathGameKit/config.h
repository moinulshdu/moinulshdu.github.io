/*
  =====================================================================
   config.h  -  EVERYTHING YOU MIGHT WANT TO CHANGE LIVES HERE
  =====================================================================
   Pins, settings, colors and sound numbers for the Math Game Kit.
   The hardware never changes between games, so new games can reuse
   all of this.
*/
#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>


// ---------------------------------------------------------------------
//  Session settings (used by every MATH game: MUSA's games)
// ---------------------------------------------------------------------
const int PROBLEMS_PER_SESSION = 10;
const int TRIES_PER_PROBLEM    = 3;

// How many easy / medium / hard problems in one session (adds up to 10)
const int EASY_COUNT   = 5;               // 50%
const int MEDIUM_COUNT = 3;               // 30%
const int HARD_COUNT   = 2;               // 20%

// How far easy / hard problems sit below / above the kid's level
const int EASY_OFFSET   = -3;
const int MEDIUM_OFFSET =  0;
const int HARD_OFFSET   = +3;

// How the level changes after each problem
const int CHANGE_FIRST_TRY  = +1;
const int CHANGE_SECOND_TRY =  0;
const int CHANGE_THIRD_TRY  = -1;
const int CHANGE_NOT_SOLVED = -2;

const int LEVEL_MIN   = 1;
const int LEVEL_MAX   = 20;
const int LEVEL_START = 3;                // level the very first time

// A wrong answer is "close" within CLOSE_MIN, or CLOSE_PERCENT % of the answer
const int CLOSE_MIN     = 2;
const int CLOSE_PERCENT = 10;

// Set to true, upload once to wipe the saved levels, then set back to false
const bool RESET_PROGRESS = false;

// Screen goes dark after this many seconds without a key press (saves battery)
const unsigned long SCREEN_SLEEP_SECONDS = 120;

// Speaker volume: 0 (silent) .. 30 (loudest). Keep it around 20 on battery.
const int SPEAKER_VOLUME = 20;

// ---------------------------------------------------------------------
//  Battery meter: 21700 cell voltage, taken after the toggle switch
//  (TP4056 OUT+ side), through a 100k + 100k divider into A6
// ---------------------------------------------------------------------
const long BATTERY_FULL_MV  = 4150;       // 100%
const long BATTERY_EMPTY_MV = 3400;       //   0%  (charge it now)
const long BATTERY_USB_MV   = 2500;       // below this: no battery, running on USB
const long DIVIDER_TOP      = 100000;     // cell + side
const long DIVIDER_BOTTOM   = 100000;     // GND side

// ---------------------------------------------------------------------
//  PINS  (Arduino Nano)  -  must match the wiring slides
// ---------------------------------------------------------------------
// Screen (2.8" ILI9341, SPI). Every line goes through a 1k / 2k divider
// (1k in the wire, 2k from the screen pin to GND: 5V -> 3.33V).
const int PIN_TFT_CS  = 10;
const int PIN_TFT_DC  = 9;
const int PIN_TFT_RST = 8;
const int PIN_TFT_LED = 6;                // backlight: HIGH = on
// D11 = MOSI (screen SDI) and D13 = SCK (screen SCK) are fixed by the Nano.
// SPI speed: lower it to 4000000 if the screen shows garbage.
const unsigned long SPI_SPEED = 8000000;

// Keypad 4x4
const byte ROWS = 4;
const byte COLS = 4;
const char KEYS[ROWS][COLS] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};
const byte ROW_PINS[ROWS] = {2, 3, 4, 5};         // keypad R1, R2, R3, R4
const byte COL_PINS[COLS] = {A0, A1, A2, A3};     // keypad C1, C2, C3, C4

// DFPlayer Mini
const int PIN_MP3_TX   = A4;              // -> 1k resistor -> DFPlayer RX
const int PIN_MP3_BUSY = A7;              // DFPlayer BUSY (A7 can only be read with analogRead)

// Battery
const int PIN_BATTERY  = A6;              // middle of the 100k / 100k divider

// Free for future ideas: D7, D12, A5

// ---------------------------------------------------------------------
//  Sound numbers  ->  /mp3/0001.mp3, /mp3/0002.mp3, ... on the DFPlayer card
// ---------------------------------------------------------------------
const int SND_WELCOME      = 1;   // "Who wants to play? If Musa wants to play, press A.
                                  //  If Isa wants to play, press B."
const int SND_START        = 2;   // "Let's go! Ten problems. You can do it!"
const int SND_RIGHT_FIRST  = 3;   // "You did it MUSA, amazing! Try the next one."
const int SND_RIGHT_RETRY  = 4;   // "MUSA, you are doing great!! Solve the next problem."
const int SND_CLOSE        = 5;   // "Pretty close, but not correct yet. Try one more time."
const int SND_FAR          = 6;   // "You need to do better than this, keep trying."
const int SND_OUT_OF_TRIES = 7;   // "That was a tricky one. Look at the answer..."
const int SND_SESSION_DONE = 8;   // "You finished all ten! I am so proud of you!"
const int SND_EXTRA_PRAISE = 9;   // first of the extra cheers: 0009.mp3, 0010.mp3, ...
const int EXTRA_PRAISE_COUNT = 2; // how many extra cheers you recorded (0 = none)

// ISA's letters game (key B)
const int SND_LETTER_A    = 11;   // 0011.mp3 = "A, A for apple" ... 0036.mp3 = "Z, Z for zebra"
const int SND_ISA_CHEER   = 37;   // first of Isa's short cheers: 0037.mp3, 0038.mp3, ...
const int ISA_CHEER_COUNT = 3;    // how many Isa cheers you recorded (0 = none)

// Hold # this long (milliseconds) to leave the letters game and go back to the menu.
// A short press of any key just shows the next letter.
const unsigned long EXIT_HOLD_MS = 3000;

// ---------------------------------------------------------------------
//  Screen colors (RGB565; search "RGB565 color picker" to make your own)
// ---------------------------------------------------------------------
const uint16_t COLOR_BACKGROUND = 0x0000;   // black
const uint16_t COLOR_BAR        = 0x2945;   // dark grey top bar
const uint16_t COLOR_TEXT       = 0xFFFF;   // white
const uint16_t COLOR_ANSWER     = 0xFFE0;   // yellow
const uint16_t COLOR_HINT       = 0x8410;   // grey
const uint16_t COLOR_RIGHT      = 0x07E0;   // green
const uint16_t COLOR_CLOSE      = 0xFC00;   // orange
const uint16_t COLOR_WRONG      = 0xF800;   // red

// ---------------------------------------------------------------------
//  What a game is
//  There are two kinds of games:
//   1) A MATH game is ONE function that makes a problem for a given level.
//      The engine does everything else: tries, sounds, levels, saving.
//   2) An ACTIVITY (like Isa's letters) is ONE function that runs on its
//      own and returns when it's time to go back to the menu.
// ---------------------------------------------------------------------
struct Problem {
  char text[16];      // what the screen shows, like "12 + 35"
  int  answer;        // the right answer (0..999)
};

typedef void (*MakeProblemFunction)(int level, Problem &p);
typedef void (*PlayFunction)();

struct Game {
  char key;                    // menu key: 'A', 'B', 'C' ...
  const char *name;            // menu name, like "MUSA  1+2"
  MakeProblemFunction make;    // math game: makes a problem  (or nullptr)
  PlayFunction play;           // activity: runs by itself    (or nullptr)
};

const int MAX_GAMES = 8;       // room saved in EEPROM for up to 8 games

#endif
