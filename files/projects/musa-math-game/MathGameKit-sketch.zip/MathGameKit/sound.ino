/*
  =====================================================================
   sound  -  the DFPlayer Mini (plays your recorded MP3 messages)
  =====================================================================
   The Arduino only SENDS commands to the DFPlayer, one wire, 9600 baud.
   Every command is the same 10-byte message:
     start, version, length, command, no-reply, value (2 bytes),
     checksum (2 bytes), end
*/

const byte MP3_SET_VOLUME  = 0x06;   // value = 0..30
const byte MP3_PLAY_FOLDER = 0x12;   // value = file number in the /mp3 folder

void soundBegin() {
  pinMode(PIN_MP3_TX, OUTPUT);
  digitalWrite(PIN_MP3_TX, HIGH);    // a serial line rests HIGH
  delay(1500);                       // give the DFPlayer time to read its card
                                     // (if a clone stays silent at power-on, try 3000)
  mp3Command(MP3_SET_VOLUME, SPEAKER_VOLUME);
}

// Plays /mp3/000N.mp3. If waitUntilDone is true, waits for the sound to finish.
void playSound(int fileNumber, bool waitUntilDone) {
  mp3Command(MP3_PLAY_FOLDER, fileNumber);
  if (!waitUntilDone) {
    return;
  }
  delay(300);                        // give BUSY time to go LOW
  unsigned long started = millis();
  while (soundIsPlaying() && millis() - started < 15000) {
    // still playing (15 second safety limit)
  }
  delay(200);
}

// BUSY is LOW while playing. A7 can only be read with analogRead.
bool soundIsPlaying() {
  return analogRead(PIN_MP3_BUSY) < 300;
}

// Picks the praise for a right-first-try answer: 0003.mp3 or one of the extras.
int pickPraiseSound() {
  int choice = random(EXTRA_PRAISE_COUNT + 1);     // 0 = the main one
  if (choice == 0) {
    return SND_RIGHT_FIRST;
  }
  return SND_EXTRA_PRAISE + choice - 1;
}

void mp3Command(byte command, int value) {
  byte message[10] = {0x7E, 0xFF, 0x06, command, 0x00,
                      highByte(value), lowByte(value), 0, 0, 0xEF};
  int checksum = 0;
  for (int i = 1; i <= 6; i++) {
    checksum = checksum - message[i];      // checksum = minus the sum of bytes 1..6
  }
  message[7] = highByte(checksum);
  message[8] = lowByte(checksum);
  for (int i = 0; i < 10; i++) {
    mp3SendByte(message[i]);
  }
}

// Sends one byte at 9600 baud: a LOW start bit, 8 data bits (lowest first),
// then a HIGH stop bit. Each bit lasts 1/9600 s = 104 microseconds.
void mp3SendByte(byte value) {
  noInterrupts();                          // keep the timing exact
  digitalWrite(PIN_MP3_TX, LOW);           // start bit
  delayMicroseconds(100);                  // 100 + ~4 for digitalWrite = 104
  for (int bit = 0; bit < 8; bit++) {
    digitalWrite(PIN_MP3_TX, bitRead(value, bit));
    delayMicroseconds(100);
  }
  digitalWrite(PIN_MP3_TX, HIGH);          // stop bit
  delayMicroseconds(100);
  interrupts();
}
