/*
  =====================================================================
   MUSA & ISA'S GAME KIT   (version 1.1)
   Arduino Nano + 2.8" ILI9341 screen + 4x4 keypad + DFPlayer Mini
   Power: 21700 cell -> TP4056 USB-C (charge + protection) -> toggle
          switch -> J5019 (5V boost).  Full guide: README.md
  =====================================================================

  HOW THIS SKETCH IS ORGANIZED (each part is its own tab in the Arduino IDE)

    MathGameKit.ino   this tab: setup, the menu, and the math ENGINE
                      (10-problem sessions, 3 tries, adaptive levels)
    config.h          all settings and pin numbers
    games.h           the list of games on the menu
    game_addition     MUSA's addition game (one small function)
    game_letters      ISA's letters game A-Z (no score)
    screen            drawing on the screen
    keypad            reading the keypad
    sound             playing your recorded MP3 messages
    battery           the battery percentage
    storage           saving levels in the Nano's EEPROM memory

  The hardware tabs never change. A new game is one new tab plus two
  lines in games.h (see the notes there).

  HOW TO PLAY
    Menu ("Who wants to play?"):  A = MUSA (addition)   B = ISA (letters)
                                  D = progress
    MUSA:  type the answer, # = check, * = erase. Three tries per problem.
           Your recorded message plays after every try.
    ISA:   a big letter appears, its sound and a cheer play, then ANY key
           shows the next letter. Hold # for 3 seconds to go back.
    The screen goes dark after 2 minutes without a key; any key wakes it.

  LIBRARIES (Arduino IDE > Tools > Manage Libraries)
    - Adafruit ILI9341   (say YES to installing Adafruit GFX and BusIO too)
    SPI and EEPROM come with the Arduino IDE.

  BOARD SETTINGS (Tools menu)
    Board: Arduino Nano.  Processor: ATmega328P (Old Bootloader) for most
    clone Nanos. If upload fails, try ATmega328P.
*/

#include <SPI.h>
#include <EEPROM.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include "config.h"
#include "games.h"

// The screen object (used by the screen tab)
Adafruit_ILI9341 tft = Adafruit_ILI9341(PIN_TFT_CS, PIN_TFT_DC, PIN_TFT_RST);

// Saved progress (used by the storage tab)
int levels[MAX_GAMES];       // one level per game
int sessionCount = 0;        // sessions played, all games together

// The shuffled deck of difficulties for one session: 'E', 'M' or 'H'
char deck[PROBLEMS_PER_SESSION];

// Screen sleep (used by the screen and keypad tabs)
unsigned long lastKeyTime = 0;    // when a key was last pressed
unsigned long lastKeyHoldMs = 0;  // how long the last key was held down
bool screenAsleep = false;        // true while the backlight is off


// =====================================================================
//  SETUP - runs once at power on
// =====================================================================

void setup() {
  keypadBegin();
  screenBegin();
  loadProgress();
  soundBegin();
}


// =====================================================================
//  LOOP - menu, play, repeat
// =====================================================================

void loop() {
  int gameNumber = chooseGame();

  if (GAMES[gameNumber].play != nullptr) {   // an activity (Isa's letters)
    GAMES[gameNumber].play();                // runs until it's time for the menu
    return;
  }

  playSession(gameNumber);                   // a math game (Musa)
  writeText(10, 215, 2, COLOR_HINT, F("Press # to go on"));
  waitForKey('#');
}


// =====================================================================
//  THE MENU
// =====================================================================

// Shows the games and waits for a key. Returns the game's number in GAMES[].
int chooseGame() {
  while (true) {
    tft.fillScreen(COLOR_BACKGROUND);
    drawTopBar();
    tft.setCursor(6, 7);
    tft.print(F("Hi!"));

    writeText(20, 45, 3, COLOR_TEXT, F("Who's playing?"));
    for (int g = 0; g < GAME_COUNT; g++) {
      tft.setTextSize(3);
      tft.setCursor(30, 90 + g * 36);
      tft.setTextColor(COLOR_ANSWER);
      tft.print(GAMES[g].key);
      tft.setTextColor(COLOR_TEXT);
      tft.print(F("  "));
      tft.print(GAMES[g].name);
    }
    writeText(30, 215, 2, COLOR_HINT, F("D = my progress"));
    playSound(SND_WELCOME, false);         // don't wait, so he can press a key now

    char key = getKey();
    while (key == 0) {
      key = getKey();
    }
    if (key == 'D') {
      showProgress();                      // then draw the menu again
      continue;
    }
    for (int g = 0; g < GAME_COUNT; g++) {
      if (key == GAMES[g].key) {
        randomSeed(micros());              // the moment he presses = a new random start
        return g;
      }
    }
  }
}

// Shows each math game's saved level and the number of sessions played.
// (Activities like Isa's letters have no level, so they are skipped.)
void showProgress() {
  tft.fillScreen(COLOR_BACKGROUND);
  drawTopBar();
  tft.setCursor(6, 7);
  tft.print(F("Progress"));
  int row = 0;
  for (int g = 0; g < GAME_COUNT; g++) {
    if (GAMES[g].make == nullptr) {
      continue;
    }
    tft.setTextSize(3);
    tft.setTextColor(COLOR_TEXT);
    tft.setCursor(20, 50 + row * 32);
    tft.print(GAMES[g].name);
    tft.print(F(" L"));
    tft.print(levels[g]);
    row++;
  }
  writeText(20, 180, 2, COLOR_TEXT, F("Sessions played: "));
  tft.print(sessionCount);
  writeText(20, 215, 2, COLOR_HINT, F("Press # to go back"));
  waitForKey('#');
}


// =====================================================================
//  THE MATH ENGINE - one session of PROBLEMS_PER_SESSION problems
//  Works the same for every math game.
// =====================================================================

void playSession(int g) {
  int rightFirstTry = 0;
  int solved        = 0;

  makeDeck();
  showBigMessage("LET'S GO", COLOR_RIGHT);
  playSound(SND_START, true);

  for (int i = 0; i < PROBLEMS_PER_SESSION; i++) {

    // 1) How hard is this problem?
    int problemLevel = constrain(levels[g] + offsetFor(deck[i]), LEVEL_MIN, LEVEL_MAX);

    // 2) Let the game make it
    Problem p;
    GAMES[g].make(problemLevel, p);

    // 3) Ask it (returns 1, 2, 3 = which try was right, or 0 = not solved)
    int triesUsed = askProblem(p, i + 1);

    // 4) Change the level
    if (triesUsed == 1) {
      levels[g] += CHANGE_FIRST_TRY;
      rightFirstTry++;
    } else if (triesUsed == 2) {
      levels[g] += CHANGE_SECOND_TRY;
    } else if (triesUsed == 3) {
      levels[g] += CHANGE_THIRD_TRY;
    } else {
      levels[g] += CHANGE_NOT_SOLVED;
    }
    if (triesUsed > 0) {
      solved++;
    }
    levels[g] = constrain(levels[g], LEVEL_MIN, LEVEL_MAX);
  }

  sessionCount++;
  saveProgress();

  tft.fillScreen(COLOR_BACKGROUND);
  drawTopBar();
  writeText(70, 45, 6, COLOR_RIGHT, F("DONE!"));
  writeText(30, 115, 3, COLOR_TEXT, F("Solved:   "));
  tft.print(solved);
  tft.print('/');
  tft.print(PROBLEMS_PER_SESSION);
  writeText(30, 145, 3, COLOR_TEXT, F("1st try:  "));
  tft.print(rightFirstTry);
  writeText(30, 175, 3, COLOR_TEXT, F("Level:    "));
  tft.print(levels[g]);
  playSound(SND_SESSION_DONE, true);
}

// Asks one problem with up to TRIES_PER_PROBLEM tries.
// Returns which try was right (1, 2, 3...) or 0 if not solved.
int askProblem(Problem &p, int problemNumber) {
  for (int attempt = 1; attempt <= TRIES_PER_PROBLEM; attempt++) {

    int guess = readAnswer(p, problemNumber, attempt);

    if (guess == p.answer) {
      showBigMessage("RIGHT!", COLOR_RIGHT);
      if (attempt == 1) {
        playSound(pickPraiseSound(), true);
      } else {
        playSound(SND_RIGHT_RETRY, true);
      }
      return attempt;
    }

    if (attempt < TRIES_PER_PROBLEM) {
      if (isClose(guess, p.answer)) {
        showBigMessage("CLOSE!", COLOR_CLOSE);
        playSound(SND_CLOSE, true);
      } else {
        showBigMessage("AGAIN!", COLOR_WRONG);
        playSound(SND_FAR, true);
      }
    }
  }

  // Out of tries: show the answer
  tft.fillScreen(COLOR_BACKGROUND);
  drawTopBar();
  tft.setCursor(6, 7);
  tft.print(F("The answer is:"));
  showProblemLine(p.text);
  showAnswerLine(p.answer, COLOR_RIGHT);
  playSound(SND_OUT_OF_TRIES, true);
  delay(2000);
  return 0;
}

// Shows the problem and lets the kid type an answer. Returns the number typed.
int readAnswer(Problem &p, int problemNumber, int attempt) {
  int typed  = 0;
  int digits = 0;

  tft.fillScreen(COLOR_BACKGROUND);
  drawTopBar();
  tft.setCursor(6, 7);
  tft.print(F("Problem "));
  tft.print(problemNumber);
  tft.print('/');
  tft.print(PROBLEMS_PER_SESSION);
  tft.setTextColor(COLOR_HINT);
  tft.setCursor(6, 36);
  tft.print(F("Try "));
  tft.print(attempt);
  tft.print(F(" of "));
  tft.print(TRIES_PER_PROBLEM);

  showProblemLine(p.text);
  writeText(40, 215, 2, COLOR_HINT, F("#  check    *  erase"));
  showAnswerLine(-1, COLOR_ANSWER);          // -1 = nothing typed yet

  while (true) {
    char key = getKey();
    if (key >= '0' && key <= '9' && digits < 3) {
      typed = typed * 10 + (key - '0');      // add the digit on the right
      digits++;
      showAnswerLine(typed, COLOR_ANSWER);
    }
    else if (key == '*' && digits > 0) {
      typed = typed / 10;                    // remove the right-most digit
      digits--;
      showAnswerLine(digits > 0 ? typed : -1, COLOR_ANSWER);
    }
    else if (key == '#' && digits > 0) {
      return typed;
    }
    // A, B, C, D and nothing-pressed: ignored here
  }
}


// =====================================================================
//  ENGINE HELPERS (games use pickNumber and makeText)
// =====================================================================

// Fills the deck with E/M/H cards and shuffles it.
void makeDeck() {
  int n = 0;
  for (int i = 0; i < EASY_COUNT;   i++) deck[n++] = 'E';
  for (int i = 0; i < MEDIUM_COUNT; i++) deck[n++] = 'M';
  for (int i = 0; i < HARD_COUNT;   i++) deck[n++] = 'H';
  for (int i = PROBLEMS_PER_SESSION - 1; i > 0; i--) {
    int j = random(i + 1);
    char temp = deck[i];
    deck[i] = deck[j];
    deck[j] = temp;
  }
}

int offsetFor(char card) {
  if (card == 'E') return EASY_OFFSET;
  if (card == 'H') return HARD_OFFSET;
  return MEDIUM_OFFSET;
}

// A random number from minVal up to a "top" that grows with the level.
// Level 1 -> small numbers.  Level 20 -> the full range up to maxVal.
int pickNumber(int minVal, int maxVal, int level) {
  int top = minVal + (long)(maxVal - minVal) * level / LEVEL_MAX;
  if (top <= minVal) {
    top = minVal + 1;
  }
  return random(minVal, top + 1);
}

// Writes "a + b" into the problem's text.
void makeText(Problem &p, int a, char symbol, int b) {
  char number[6];
  char middle[4] = {' ', symbol, ' ', '\0'};
  itoa(a, p.text, 10);
  strcat(p.text, middle);
  itoa(b, number, 10);
  strcat(p.text, number);
}

bool isClose(int guess, int answer) {
  int window = answer * CLOSE_PERCENT / 100;
  if (window < CLOSE_MIN) {
    window = CLOSE_MIN;
  }
  return abs(guess - answer) <= window;
}
