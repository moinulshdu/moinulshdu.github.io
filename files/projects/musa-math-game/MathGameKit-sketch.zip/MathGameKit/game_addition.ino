/*
  =====================================================================
   game_addition  -  ADAPTIVE ADDITION
  =====================================================================
   A game is one function: given a level (1..20), fill in the problem
   text and the answer. Higher level = bigger numbers.

   Level 1  ->  1..3   +  5..7
   Level 10 ->  1..25  +  5..32
   Level 20 ->  1..50  +  5..60

   To make a new game, copy this tab and change only the numbers and
   the answer line. For example subtraction:
       int a = pickNumber(5, 60, level);
       int b = pickNumber(1, a, level);          // never bigger than a
       p.answer = a - b;
       makeText(p, a, '-', b);
*/

const int ADD_A_MIN = 1,  ADD_A_MAX = 50;   // first number
const int ADD_B_MIN = 5,  ADD_B_MAX = 60;   // second number

void makeAddition(int level, Problem &p) {
  int a = pickNumber(ADD_A_MIN, ADD_A_MAX, level);
  int b = pickNumber(ADD_B_MIN, ADD_B_MAX, level);
  p.answer = a + b;
  makeText(p, a, '+', b);
}
