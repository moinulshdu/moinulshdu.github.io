/*
  =====================================================================
   keypad  -  the 4x4 membrane keypad
  =====================================================================
   Each key joins one row wire to one column wire. We pull one column
   LOW at a time and look for a row that turned LOW too: that's the key.
*/

void keypadBegin() {
  for (int r = 0; r < ROWS; r++) {
    pinMode(ROW_PINS[r], INPUT_PULLUP);    // rows read HIGH until a key is pressed
  }
  for (int c = 0; c < COLS; c++) {
    pinMode(COL_PINS[c], INPUT);           // columns rest "off"
  }
}

// Returns the key pressed ('0'-'9', '*', '#', 'A'-'D'), or 0 if nothing.
// Waits until the key is let go, so one press = one key.
// lastKeyHoldMs then tells how long it was held (used to leave Isa's game).
// Also puts the screen to sleep when nobody has pressed a key for a while.
char getKey() {
  if (!screenAsleep && millis() - lastKeyTime > SCREEN_SLEEP_SECONDS * 1000) {
    screenSleep();
  }

  for (int c = 0; c < COLS; c++) {
    pinMode(COL_PINS[c], OUTPUT);
    digitalWrite(COL_PINS[c], LOW);        // "ask" this column

    for (int r = 0; r < ROWS; r++) {
      if (digitalRead(ROW_PINS[r]) == LOW) {   // this row answered: key found
        unsigned long pressedAt = millis();
        delay(20);                             // ignore the contact bounce
        while (digitalRead(ROW_PINS[r]) == LOW) {
          // wait for the finger to come off
        }
        lastKeyHoldMs = millis() - pressedAt;  // how long the key was held
        delay(20);
        pinMode(COL_PINS[c], INPUT);
        lastKeyTime = millis();
        if (screenAsleep) {                    // this press only wakes the screen
          screenWake();
          return 0;
        }
        return KEYS[r][c];
      }
    }

    pinMode(COL_PINS[c], INPUT);           // stop asking this column
  }
  return 0;
}

void waitForKey(char wanted) {
  while (getKey() != wanted) {
    // just wait
  }
}
