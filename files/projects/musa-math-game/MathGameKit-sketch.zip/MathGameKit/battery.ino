/*
  =====================================================================
   battery  -  the battery percentage
  =====================================================================
   Two 100k resistors halve the cell voltage (4.2 V -> 2.1 V) so pin A6
   can read it. We measure, then multiply back up.
*/

// Returns 0..100, or -1 when there is no battery (running on USB).
int batteryPercent() {
  long total = 0;
  for (int i = 0; i < 8; i++) {            // average 8 readings
    total += analogRead(PIN_BATTERY);
  }
  long pinMillivolts     = total / 8 * 5000 / 1023;
  long batteryMillivolts = pinMillivolts * (DIVIDER_TOP + DIVIDER_BOTTOM) / DIVIDER_BOTTOM;

  if (batteryMillivolts < BATTERY_USB_MV) {
    return -1;
  }
  long percent = (batteryMillivolts - BATTERY_EMPTY_MV) * 100
                 / (BATTERY_FULL_MV - BATTERY_EMPTY_MV);
  return constrain(percent, 0, 100);
}
