/*
  =====================================================================
   screen  -  the 2.8" ILI9341 color screen
  =====================================================================
   The screen is 320 pixels wide and 240 tall (landscape). (0,0) is the
   top-left corner. Text size 1 letters are 6 x 8 pixels; size 6 letters
   are 36 x 48.
*/

void screenBegin() {
  pinMode(PIN_TFT_LED, OUTPUT);
  digitalWrite(PIN_TFT_LED, HIGH);         // backlight on
  tft.begin(SPI_SPEED);
  tft.setRotation(1);                      // landscape: 320 wide x 240 tall
  tft.fillScreen(COLOR_BACKGROUND);
  writeText(10, 40, 3, COLOR_TEXT, F("Starting..."));
}

void screenSleep() {
  digitalWrite(PIN_TFT_LED, LOW);
  screenAsleep = true;
}

void screenWake() {
  digitalWrite(PIN_TFT_LED, HIGH);
  screenAsleep = false;
}

// Small text at pixel (x, y). F("...") keeps the text out of the Nano's small RAM.
void writeText(int x, int y, int size, uint16_t color, const __FlashStringHelper *text) {
  tft.setTextSize(size);
  tft.setTextColor(color);
  tft.setCursor(x, y);
  tft.print(text);
}

// Text in the middle of the screen, left to right.
void writeCentered(int y, int size, uint16_t color, const char *text) {
  int width = strlen(text) * 6 * size;
  tft.setTextSize(size);
  tft.setTextColor(color);
  tft.setCursor((320 - width) / 2, y);
  tft.print(text);
}

// The grey bar at the top with the battery on the right.
// Leaves the cursor ready for white size-2 text on the bar.
void drawTopBar() {
  tft.fillRect(0, 0, 320, 30, COLOR_BAR);
  drawBattery();
  tft.setTextSize(2);
  tft.setTextColor(COLOR_TEXT);
}

// "85%" and a battery icon in the top-right corner.
void drawBattery() {
  int percent = batteryPercent();
  uint16_t color = COLOR_RIGHT;
  if (percent <= 50) color = COLOR_ANSWER;
  if (percent <= 20) color = COLOR_WRONG;

  tft.setTextSize(2);
  tft.setTextColor(color);
  tft.setCursor(222, 8);
  if (percent < 0) {
    tft.print(F(" USB"));
    percent = 100;
    color = COLOR_HINT;
  } else {
    if (percent < 100) tft.print(' ');
    if (percent < 10)  tft.print(' ');
    tft.print(percent);
    tft.print('%');
  }
  tft.drawRect(274, 7, 36, 17, COLOR_TEXT);
  tft.fillRect(310, 11, 4, 9, COLOR_TEXT);
  tft.fillRect(276, 9, 32 * percent / 100, 13, color);
}

// The big problem in the middle, like "12 + 35"
void showProblemLine(const char *text) {
  writeCentered(60, 6, COLOR_TEXT, text);
}

// The answer line under it, like "= 47". Use -1 to show just "=".
void showAnswerLine(int value, uint16_t color) {
  char line[8] = "= ";
  if (value >= 0) {
    itoa(value, line + 2, 10);
  }
  tft.fillRect(0, 130, 320, 60, COLOR_BACKGROUND);
  writeCentered(135, 6, color, line);
}

// Whole screen in one color with a big word on it (max 8 letters).
void showBigMessage(const char *message, uint16_t color) {
  tft.fillScreen(color);
  writeCentered(96, 6, COLOR_BACKGROUND, message);
}
