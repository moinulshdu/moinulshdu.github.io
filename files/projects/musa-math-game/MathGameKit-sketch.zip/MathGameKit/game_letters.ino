/*
  =====================================================================
   game_letters  -  ISA'S LETTERS  (A to Z, no score)
  =====================================================================
   For a 2-year-old: a big colorful letter appears, the recorded sound
   plays ("G, G for goat"), then a short cheer, then ANY key shows the
   next letter. All 26 letters come in a random order before any letter
   repeats. Nothing is scored or saved.

   Hold # for 3 seconds (EXIT_HOLD_MS in config.h) to go back to the menu.

   SOUND FILES (folder mp3 on the card)
     0011.mp3 = A ... 0036.mp3 = Z      (letter number + 10)
     0037.mp3, 0038.mp3, 0039.mp3        short cheers (ISA_CHEER_COUNT)

   WORDS on the screen under the letter: change them to match what you
   say in your recordings (max 9 letters each).
*/

const char LETTER_WORDS[26][10] PROGMEM = {
  "Apple",    "Ball",   "Cat",      "Dog",    "Elephant", "Fish",
  "Goat",     "Hat",    "Ice cream","Juice",  "Kite",     "Lion",
  "Moon",     "Nest",   "Orange",   "Pig",    "Queen",    "Rabbit",
  "Sun",      "Tree",   "Umbrella", "Van",    "Whale",    "Xylophone",
  "Yo-yo",    "Zebra"
};

// Bright colors the letters take turns in
const uint16_t LETTER_COLORS[] = {
  ILI9341_RED, ILI9341_ORANGE, ILI9341_YELLOW, ILI9341_GREEN,
  ILI9341_CYAN, ILI9341_MAGENTA, ILI9341_PINK, ILI9341_GREENYELLOW
};
const int LETTER_COLOR_COUNT = sizeof(LETTER_COLORS) / sizeof(LETTER_COLORS[0]);

void playLetters() {
  char order[26];
  int next = 26;                     // 26 = "used up", so we shuffle first
  int colorNumber = random(LETTER_COLOR_COUNT);

  while (true) {
    // 1) Shuffle a fresh A..Z order when all 26 have been shown
    if (next >= 26) {
      for (int i = 0; i < 26; i++) {
        order[i] = 'A' + i;
      }
      for (int i = 25; i > 0; i--) {
        int j = random(i + 1);
        char temp = order[i];
        order[i] = order[j];
        order[j] = temp;
      }
      next = 0;
    }
    char letter = order[next];
    next++;

    // 2) Show it, say it, cheer
    showLetter(letter, LETTER_COLORS[colorNumber]);
    colorNumber = (colorNumber + 1) % LETTER_COLOR_COUNT;
    playSound(SND_LETTER_A + (letter - 'A'), true);
    if (ISA_CHEER_COUNT > 0) {
      playSound(SND_ISA_CHEER + random(ISA_CHEER_COUNT), true);
    }

    // 3) Any key = next letter.  # held for EXIT_HOLD_MS = back to the menu
    char key = getKey();
    while (key == 0) {
      key = getKey();
    }
    if (key == '#' && lastKeyHoldMs >= EXIT_HOLD_MS) {
      return;
    }
  }
}

// Big "G g" in color, the word under it, and a small hint for grown-ups.
void showLetter(char letter, uint16_t color) {
  char big[4] = {letter, ' ', (char)(letter + 32), '\0'};   // "G g"
  char word[10];
  strcpy_P(word, LETTER_WORDS[letter - 'A']);

  tft.fillScreen(COLOR_BACKGROUND);
  drawTopBar();
  tft.setCursor(6, 7);
  tft.print(F("ISA"));

  writeCentered(48, 12, color, big);          // 72 x 96 pixel letters
  writeCentered(160, 4, COLOR_TEXT, word);
  writeCentered(218, 2, COLOR_HINT, "hold # = menu");
}
